package com.example.books.spring.boot.rest.repostory;

import org.springframework.stereotype.Repository;

import com.example.books.spring.boot.rest.model.Subscription;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Integer>{
	
}
