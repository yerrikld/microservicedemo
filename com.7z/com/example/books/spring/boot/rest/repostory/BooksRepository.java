package com.example.books.spring.boot.rest.repostory;

import org.springframework.stereotype.Repository;

import com.example.books.spring.boot.rest.model.Books;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface BooksRepository extends JpaRepository<Books, Integer>{
	/*
	 * @Query(value="Select * from BOOKS where Name=:name",nativeQuery = true)
	 * List<Books> getAuthorsBYName(String name);
	 * 
	 * @Query("SELECT u FROM User u WHERE u.status = ?1 and u.name = ?2") User
	 * findUserByStatusAndName(Integer status, String name);
	 * 
	 * @Query("SELECT u FROM User u WHERE u.status = :status and u.name = :name")
	 * User findUserByUserStatusAndUserName(@Param("status") Integer userStatus,
	 * 
	 * @Param("name") String userName);
	 */
}
