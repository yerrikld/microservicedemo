package com.example.books.spring.boot.rest.basicAuth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@EnableWebSecurity
public class BasicAuthentication extends WebSecurityConfigurerAdapter {
	@Autowired
	UserService userSerrvice;

	@Override
	protected void configure(AuthenticationManagerBuilder auth) {
		try {
			auth.userDetailsService(userSerrvice);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
