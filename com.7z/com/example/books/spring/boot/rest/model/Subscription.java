package com.example.books.spring.boot.rest.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;


@Entity
public class Subscription {
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "book_seq")
	 * 
	 * @GenericGenerator(name = "book_seq", strategy =
	 * "org.thoughts.on.java.generators.StringPrefixedSequenceIdGenerator",
	 * parameters = {
	 * 
	 * @Parameter(name = StringPrefixedSequenceIdGenerator.INCREMENT_PARAM, value =
	 * "50"),
	 * 
	 * @Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER,
	 * value = "B"),
	 * 
	 * @Parameter(name = StringPrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER,
	 * value = "%05d") })
	 */
	@Id
	@GeneratedValue
	private Integer subscriberId;
	public Integer getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}
	public String getSubscriberName() {
		return subscriberName;
	}
	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}
	public Date getDateSubscribed() {
		return dateSubscribed;
	}
	public void setDateSubscribed(Date dateSubscribed) {
		this.dateSubscribed = dateSubscribed;
	}
	public Date getDateReturned() {
		return dateReturned;
	}
	public void setDateReturned(Date dateReturned) {
		this.dateReturned = dateReturned;
	}
	public Books getBooks() {
		return books;
	}
	public void setBooks(Books books) {
		this.books = books;
	}
	@NotBlank(message = "Subscriber name not empty")
	private String subscriberName;
	private Date dateSubscribed;
	private Date dateReturned; 
	@ManyToOne
	@JoinColumn(name="bookId",insertable = false, updatable = false)
	private Books books;
	
}
