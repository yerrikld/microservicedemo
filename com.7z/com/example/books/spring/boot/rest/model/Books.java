package com.example.books.spring.boot.rest.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;


@Entity
public class Books implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*
	 * @GenericGenerator(name = "book_seq", strategy =
	 * "org.thoughts.on.java.generators.StringPrefixedSequenceIdGenerator",
	 * parameters = {
	 * 
	 * @Parameter(name = StringPrefixedSequenceIdGenerator.INCREMENT_PARAM, value =
	 * "50"),
	 * 
	 * @Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER,
	 * value = "B"),
	 * 
	 * @Parameter(name = StringPrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER,
	 * value = "%05d") })
	 * 
	 * @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "book_seq")
	 */
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.AUTO)
	 */

	@Id
	@Column(name = "BOOKID")
	@SequenceGenerator(name = "stu_seq", sequenceName = "B_", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "stu_seq")

	/*
	 * @Id
	 * 
	 * @GeneratedValue
	 */
	@Min(1)
	@Max(1000)
	private Integer bookId;
	@NotBlank(message = "Book name not empty")
	private String name;
	public Integer getBookId() {
		return bookId;
	}
	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Integer getCopiesAvailable() {
		return copiesAvailable;
	}
	public void setCopiesAvailable(Integer copiesAvailable) {
		this.copiesAvailable = copiesAvailable;
	}
	public Integer getTotalCopies() {
		return totalCopies;
	}
	public void setTotalCopies(Integer totalCopies) {
		this.totalCopies = totalCopies;
	}
	@NotBlank(message = "Book author name not empty")
	private String author;
	private Integer copiesAvailable;
	private Integer totalCopies;
}
