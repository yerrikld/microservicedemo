package com.example.books.spring.boot.rest.advice;

import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;
@EnableAspectJAutoProxy
@Component
@Aspect
public class LoggingAspect {
	private Logger logger = Logger.getLogger(LoggingAspect.class.getName());

	@Before("execution(* com.example.books.spring.boot.rest.controller.*.*())") // point-cut expression
	public void logBeforeV1(JoinPoint joinPoint) {
		System.out.println("Class Name: " + joinPoint.getSignature().getClass());
		System.out.println("Method Name : " + joinPoint.getSignature().getName());

	}

	@Around("execution(* com.example.books.spring.boot.rest.controller.BooksController.*(..))")
	public void controllerLogAround() {
		System.out.println("Around with controllers");
	}

	@After("execution(* com.example.books.spring.boot.rest.controller.BooksController.*(..))")
	public void controllerLogAfter() {
		System.out.println("After calling BooksController methods");
	}
	@AfterReturning("execution(* com.example.books.spring.boot.rest.controller.BooksController.*(..))")
	public void controllerLogAfterReturning() {
		System.out.println("AfterReturning BooksController methods");
	}
	@AfterThrowing("execution(* com.example.books.spring.boot.rest.controller.BooksController.*(..))")
	public void controllerLogAfterThrowing() {
		System.out.println("AfterThrowing BooksController methods");
	}
	
	/*
	 * @AfterThrowing("within(* com.example.books.spring.boot.rest.controller..*)")
	 * public void controllerAfterThrowingInPackage() { System.out.
	 * println("AfterThrowing in all classes and sub package classes methods"); }
	 */

}
