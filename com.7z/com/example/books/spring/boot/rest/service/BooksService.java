package com.example.books.spring.boot.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.books.spring.boot.rest.model.Books;
import com.example.books.spring.boot.rest.repostory.BooksRepository;

@Service
public class BooksService {
	
	@Autowired
	BooksRepository booksRepository;

	public List<Books> fetchAllBooks() {
		return booksRepository.findAll();
	}

	public Integer addbooks(Books books) {

		booksRepository.save(books);
		return books.getBookId();
	}

	public void updatebooks(Books books) {
		booksRepository.save(books);
	}

	public Books get(Integer bookId) {
		Optional<Books> book = Optional.ofNullable(booksRepository.getById(bookId));
		return book.isPresent() ? book.get() : null;
	}

	
	/*
	 * public void deletebooks(String bookId) {
	 * 
	 * booksRepository.deleteById(bookId); }
	 * 
	 * 
	 * public void clear() { booksRepository.deleteAll(); }
	 */

}
