package com.example.books.spring.boot.rest.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.books.spring.boot.rest.model.Subscription;
import com.example.books.spring.boot.rest.repostory.SubscriptionRepository;

@Service
public class SubscriptionService {
	
	@Autowired
	SubscriptionRepository subscriptionRepository;

	public List<Subscription> fetchAllSubscription() {
		return subscriptionRepository.findAll();
	}

	public Integer addsubscription(@Valid Subscription subscription) {
		subscriptionRepository.save(subscription);
		return subscription.getSubscriberId();
	}

	public void updatesubscription(Subscription subscription) {
		subscriptionRepository.save(subscription);
	}

	public Subscription get(Integer subscriberId) {
		Optional<Subscription> subcription = subscriptionRepository.findById(subscriberId);
		return subcription.isPresent() ? subcription.get() : null;
	}

	/*
	 * public void deletesubscription(String subscriberId) {
	 * 
	 * subscriptionRepository.deleteById(subscriberId); }
	 * 
	 * public void clear() { subscriptionRepository.deleteAll(); }
	 */

}
